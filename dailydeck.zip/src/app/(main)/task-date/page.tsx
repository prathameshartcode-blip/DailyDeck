'use client';

import { useState } from 'react';
import { useTaskLogs } from '@/lib/hooks/useTaskLogs';
import { Plus, Trash2, Calendar, Search, Lightbulb, Bug, Users, Sparkles, CheckCircle2, Circle, AlertCircle } from 'lucide-react';

const QUICK_TYPES = [
  { name: 'idea', label: 'Idea', icon: Lightbulb, color: 'text-amber-500 bg-zinc-900 border-zinc-800' },
  { name: 'bug', label: 'Bug', icon: Bug, color: 'text-red-500 bg-zinc-900 border-zinc-800' },
  { name: 'meeting', label: 'Meeting', icon: Users, color: 'text-purple-500 bg-zinc-900 border-zinc-800' },
  { name: 'task', label: 'Task', icon: CheckCircle2, color: 'text-blue-500 bg-zinc-900 border-zinc-800' },
];

export default function TaskDatePage() {
  const { logs, loading, addLog, toggleStatus, deleteLog } = useTaskLogs();
  const [type, setType] = useState('');
  const [note, setNote] = useState('');
  const [logDate, setLogDate] = useState(new Date().toISOString().split('T')[0]);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'complete'>('all');

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!type.trim()) return;
    await addLog(type.trim().toLowerCase(), note.trim(), logDate);
    setType('');
    setContent('');
  };

  const setContent = (val: string) => {
    setNote(val);
  };

  const getLogTypeColor = (typeName: string) => {
    switch (typeName.toLowerCase()) {
      case 'bug':
        return 'text-red-400 border-red-900/50 bg-red-950/10';
      case 'idea':
        return 'text-amber-400 border-amber-900/50 bg-amber-950/10';
      case 'meeting':
        return 'text-purple-400 border-purple-900/50 bg-purple-950/10';
      case 'task':
        return 'text-blue-400 border-blue-900/50 bg-blue-950/10';
      default:
        return 'text-zinc-400 border-zinc-800 bg-zinc-900/40';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="w-5 h-5 border-2 border-zinc-700 border-t-zinc-300 rounded-full animate-spin"></div>
      </div>
    );
  }

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.type.toLowerCase().includes(search.toLowerCase()) ||
      (log.note && log.note.toLowerCase().includes(search.toLowerCase()));

    const matchesStatus =
      statusFilter === 'all' ? true : log.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Log creation form */}
      <div className="bg-zinc-900/30 border border-zinc-850 rounded-md p-4 space-y-4">
        <h3 className="text-xs font-semibold text-zinc-300">New Timeline Event</h3>
        
        <form onSubmit={handleAdd} className="space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Type / Tag</label>
              <input
                value={type}
                onChange={(e) => setType(e.target.value)}
                placeholder="e.g. bug, idea, meeting"
                className="w-full px-3 py-1.5 rounded bg-zinc-950 border border-zinc-800 outline-none focus:border-zinc-700 text-xs text-zinc-200 placeholder:text-zinc-650"
              />
            </div>
            
            <div className="space-y-1">
              <label className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Date</label>
              <input
                type="date"
                value={logDate}
                onChange={(e) => setLogDate(e.target.value)}
                className="w-full px-3 py-1.5 rounded bg-zinc-950 border border-zinc-800 outline-none focus:border-zinc-700 text-xs text-zinc-200"
              />
            </div>

            <div className="flex items-end">
              <button
                type="submit"
                className="w-full h-8 rounded bg-zinc-200 hover:bg-white text-black text-xs font-semibold transition-all active:scale-[0.98]"
              >
                Log Entry
              </button>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">Note / Description</label>
            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Provide event details..."
              className="w-full px-3 py-1.5 rounded bg-zinc-950 border border-zinc-800 outline-none focus:border-zinc-700 text-xs text-zinc-200 placeholder:text-zinc-650"
            />
          </div>

          {/* Quick Select Buttons */}
          <div className="flex items-center gap-1.5 flex-wrap pt-1">
            <span className="text-[10px] text-zinc-500 uppercase font-semibold">Quick Type:</span>
            {QUICK_TYPES.map((qt) => {
              const Icon = qt.icon;
              return (
                <button
                  type="button"
                  key={qt.name}
                  onClick={() => setType(qt.name)}
                  className="flex items-center gap-1 text-[10px] px-2 py-0.5 rounded border border-zinc-800 bg-zinc-900 text-zinc-300 hover:border-zinc-700 transition-colors"
                >
                  <Icon className="w-3 h-3 text-zinc-500" />
                  {qt.label}
                </button>
              );
            })}
          </div>
        </form>
      </div>

      {/* Control panel */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between pb-2 border-b border-zinc-900">
        <div className="flex bg-zinc-900/50 p-0.5 rounded border border-zinc-800 self-start">
          {(['all', 'pending', 'complete'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setStatusFilter(filter)}
              className={`px-2.5 py-1 rounded text-[10px] font-semibold uppercase tracking-wider transition-colors ${
                statusFilter === filter
                  ? 'bg-zinc-800 text-zinc-100 border border-zinc-750'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        <div className="relative min-w-[200px] sm:w-56">
          <Search className="w-3.5 h-3.5 text-zinc-650 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search notes / tags..."
            className="w-full pl-8 pr-3 py-1 rounded bg-zinc-950 border border-zinc-850 outline-none focus:border-zinc-700 text-xs text-zinc-200 placeholder:text-zinc-650"
          />
        </div>
      </div>

      {/* Structured Vertical Timeline Feed */}
      <div className="relative pl-6 space-y-6">
        {/* The Track Line */}
        <div className="absolute left-2.5 top-2 bottom-2 w-[1px] bg-zinc-850" />

        {filteredLogs.map((log) => {
          const typeColor = getLogTypeColor(log.type);
          const isComplete = log.status === 'complete';

          return (
            <div key={log.id} className="relative group">
              {/* Timeline dot node */}
              <div 
                onClick={() => toggleStatus(log)}
                className={`absolute -left-[20.5px] top-1.5 w-2.5 h-2.5 rounded-full border cursor-pointer transition-all ${
                  isComplete 
                    ? 'bg-indigo-600 border-indigo-500 scale-110 shadow-sm shadow-indigo-500/30' 
                    : 'bg-zinc-950 border-zinc-700 hover:border-zinc-500'
                }`}
                title="Toggle status"
              />

              {/* Card content box */}
              <div className="bg-zinc-900/10 border-l-2 border-t border-r border-b border-zinc-850 hover:border-zinc-800 rounded-md p-3.5 flex items-center justify-between gap-4 transition-colors">
                <div className="min-w-0 space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Minimal Outlined Tag */}
                    <span className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border ${typeColor}`}>
                      {log.type}
                    </span>
                    
                    <span className="text-[9px] text-zinc-500 font-semibold flex items-center gap-1">
                      <Calendar className="w-2.5 h-2.5" />
                      {log.log_date}
                    </span>
                  </div>

                  <p className={`text-xs leading-relaxed ${isComplete ? 'line-through text-zinc-500 font-medium' : 'text-zinc-200'}`}>
                    {log.note}
                  </p>
                </div>

                <div className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => deleteLog(log.id)}
                    className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-red-400 rounded transition-colors"
                    title="Delete event"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}

        {filteredLogs.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center border border-dashed border-zinc-850 rounded">
            <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold">Timeline Empty</p>
          </div>
        )}
      </div>
    </div>
  );
}



