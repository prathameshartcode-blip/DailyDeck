'use client';

import { useState } from 'react';
import { useTasks, type Task } from '@/lib/hooks/useTasks';
import { Plus, Trash2, CheckCircle2, Circle, RefreshCw, GripVertical } from 'lucide-react';

export default function DailyTasksPage() {
  const { tasks, loading, addTask, toggleStatus, deleteTask } = useTasks();
  const [title, setTitle] = useState('');
  const [isRecurring, setIsRecurring] = useState(false);
  const [draggingTaskId, setDraggingTaskId] = useState<string | null>(null);

  const pending = tasks.filter((t) => t.status === 'pending');
  const complete = tasks.filter((t) => t.status === 'complete');
  
  const totalCount = tasks.length;
  const completedCount = complete.length;
  const completionPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
  const activePercentage = totalCount > 0 ? 100 - completionPercentage : 100;

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    await addTask(title.trim(), isRecurring);
    setTitle('');
    setIsRecurring(false);
  };

  const handleDragStart = (e: React.DragEvent, id: string) => {
    setDraggingTaskId(id);
    e.dataTransfer.setData('text/plain', id);
  };

  const handleDragEnd = () => {
    setDraggingTaskId(null);
  };

  const handleDrop = async (targetStatus: 'pending' | 'complete') => {
    if (!draggingTaskId) return;
    const task = tasks.find((t) => t.id === draggingTaskId);
    if (task && task.status !== targetStatus) {
      await toggleStatus(task);
    }
    setDraggingTaskId(null);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="w-5 h-5 border-2 border-zinc-700 border-t-zinc-300 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Simple Premium Header with Split Progress */}
      <div className="space-y-4 pb-5 border-b border-zinc-800">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-zinc-100">Tasks</h2>
            <p className="text-xs text-zinc-500">Organize and process your daily checklist.</p>
          </div>
          
          <div className="text-right text-[10px] uppercase font-bold text-zinc-500 tracking-wider">
            Active: {pending.length} &bull; Done: {complete.length}
          </div>
        </div>

        {totalCount > 0 && (
          <div className="space-y-1.5">
            <div className="flex w-full h-1.5 rounded-full overflow-hidden bg-zinc-800">
              <div 
                className="bg-zinc-500 h-full transition-all duration-300" 
                style={{ width: `${activePercentage}%` }}
              ></div>
              <div 
                className="bg-indigo-600 h-full transition-all duration-300" 
                style={{ width: `${completionPercentage}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-[9px] font-bold text-zinc-500 uppercase tracking-wider">
              <span>{pending.length > 0 ? `${activePercentage}% Active` : ''}</span>
              <span>{complete.length > 0 ? `${completionPercentage}% Complete` : ''}</span>
            </div>
          </div>
        )}
      </div>

      {/* Flat Task Creation Input */}
      <form onSubmit={handleAdd} className="flex gap-2 flex-wrap items-center bg-zinc-900/40 p-2.5 border border-zinc-850 rounded-md">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Write task name..."
          className="flex-1 min-w-[200px] px-3 py-2 rounded bg-zinc-950 border border-zinc-800 outline-none focus:border-zinc-700 text-xs text-zinc-200 placeholder:text-zinc-650"
        />
        
        {/* Toggle Style */}
        <label className="flex items-center gap-2 cursor-pointer select-none px-2 py-1.5 rounded hover:bg-zinc-800/40 transition-colors">
          <input
            type="checkbox"
            checked={isRecurring}
            onChange={(e) => setIsRecurring(e.target.checked)}
            className="sr-only peer"
          />
          <div className="relative w-7 h-4 bg-zinc-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-zinc-500 after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-indigo-600"></div>
          <span className="text-[10px] font-semibold text-zinc-500 peer-checked:text-zinc-300 uppercase tracking-wider">
            Auto-Reset
          </span>
        </label>

        <button
          type="submit"
          className="px-4 py-2 rounded bg-zinc-200 hover:bg-white text-black text-xs font-semibold transition-all active:scale-[0.98]"
        >
          Add Task
        </button>
      </form>

      {/* Kanban Board columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Column Active */}
        <Column 
          title="Active List" 
          count={pending.length}
          tasks={pending}
          onToggle={toggleStatus}
          onDelete={deleteTask}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
          onDrop={() => handleDrop('pending')}
        />

        {/* Column Complete */}
        <Column 
          title="Completed List" 
          count={complete.length}
          tasks={complete}
          onToggle={toggleStatus}
          onDelete={deleteTask}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
          onDrop={() => handleDrop('complete')}
        />
      </div>
    </div>
  );
}

function Column({
  title,
  count,
  tasks,
  onToggle,
  onDelete,
  onDragStart,
  onDragEnd,
  onDrop,
}: {
  title: string;
  count: number;
  tasks: Task[];
  onToggle: (t: Task) => void;
  onDelete: (id: string) => void;
  onDragStart: (e: React.DragEvent, id: string) => void;
  onDragEnd: () => void;
  onDrop: () => void;
}) {
  const [isOver, setIsOver] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDragEnter = () => {
    setIsOver(true);
  };

  const handleDragLeave = () => {
    setIsOver(false);
  };

  const handleLocalDrop = () => {
    setIsOver(false);
    onDrop();
  };

  return (
    <div 
      onDragOver={handleDragOver}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDrop={handleLocalDrop}
      className={`bg-zinc-950/20 border rounded-md p-4 flex flex-col min-h-[380px] transition-all ${
        isOver ? 'border-zinc-700 bg-zinc-900/10' : 'border-zinc-850'
      }`}
    >
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-zinc-900">
        <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">{title}</span>
        <span className="text-[10px] bg-zinc-900 text-zinc-500 border border-zinc-850 px-2 py-0.5 rounded font-bold">
          {count}
        </span>
      </div>

      <div className="space-y-2 flex-1">
        {tasks.map((task) => (
          <div
            key={task.id}
            draggable
            onDragStart={(e) => onDragStart(e, task.id)}
            onDragEnd={onDragEnd}
            className="group bg-zinc-900/60 border border-zinc-850 hover:border-zinc-800 rounded p-2.5 flex items-center justify-between gap-3 cursor-grab active:cursor-grabbing transition-colors select-none"
          >
            <div className="flex items-center gap-2 min-w-0">
              <GripVertical className="w-3.5 h-3.5 text-zinc-700 shrink-0 cursor-grab group-hover:text-zinc-500 transition-colors" />
              
              <button
                onClick={() => onToggle(task)}
                className="text-zinc-600 hover:text-zinc-300 transition-colors shrink-0"
              >
                {task.status === 'complete' ? (
                  <CheckCircle2 className="w-4 h-4 text-indigo-500" />
                ) : (
                  <Circle className="w-4 h-4" />
                )}
              </button>
              
              <div className="min-w-0">
                <span className={`text-xs ${
                  task.status === 'complete' ? 'line-through text-zinc-500 font-medium' : 'text-zinc-200'
                }`}>
                  {task.title}
                </span>
                {task.is_recurring && (
                  <span className="inline-flex items-center gap-0.5 text-[9px] font-bold uppercase tracking-wider text-amber-500/80 bg-amber-500/5 px-1 py-0.5 rounded ml-2 border border-amber-900/20">
                    Auto
                  </span>
                )}
              </div>
            </div>

            <div className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={() => onDelete(task.id)}
                className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-red-400 rounded transition-colors"
                title="Delete task"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
        
        {tasks.length === 0 && (
          <div className="flex flex-col items-center justify-center h-28 text-center border border-dashed border-zinc-900 rounded">
            <p className="text-[10px] text-zinc-650 uppercase font-bold tracking-wider">Drag items here</p>
          </div>
        )}
      </div>
    </div>
  );
}



