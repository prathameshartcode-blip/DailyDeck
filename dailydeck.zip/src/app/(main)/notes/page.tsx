'use client';

import { useState } from 'react';
import { useNotes } from '@/lib/hooks/useNotes';
import { Plus, Trash2, Calendar, Edit3 } from 'lucide-react';

export default function NotesPage() {
  const { grouped, loading, addNote, deleteNote } = useNotes();
  const [content, setContent] = useState('');

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    await addNote(content.trim());
    setContent('');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="w-5 h-5 border-2 border-zinc-700 border-t-zinc-300 rounded-full animate-spin"></div>
      </div>
    );
  }

  const dates = Object.keys(grouped).sort((a, b) => (a < b ? 1 : -1));
  const totalNotes = Object.values(grouped).reduce((acc, curr) => acc + curr.length, 0);

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header section */}
      <div className="flex items-center justify-between pb-4 border-b border-zinc-800">
        <div>
          <h2 className="text-base font-semibold text-zinc-100">Notes Log</h2>
          <p className="text-xs text-zinc-500">Capture daily achievements, tasks log, and thoughts.</p>
        </div>
        <div className="text-[10px] uppercase font-bold text-zinc-500 bg-zinc-900 border border-zinc-850 px-2 py-1 rounded">
          Logs: <span className="text-zinc-200">{totalNotes}</span>
        </div>
      </div>

      {/* Input box */}
      <form onSubmit={handleAdd} className="flex gap-2 bg-zinc-900/40 p-2.5 border border-zinc-850 rounded-md">
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Log a note or thought..."
          rows={2}
          className="flex-1 px-3 py-2 rounded bg-zinc-950 border border-zinc-800 outline-none focus:border-zinc-700 text-xs text-zinc-200 placeholder:text-zinc-650 resize-none"
        />
        <button
          type="submit"
          className="px-4 py-2 rounded bg-zinc-200 hover:bg-white text-black text-xs font-semibold transition-all self-end active:scale-[0.98]"
        >
          Save Note
        </button>
      </form>

      {/* Asymmetrical notes feed */}
      <div className="space-y-10">
        {dates.map((date) => {
          const dateObj = new Date(date);
          const weekday = dateObj.toLocaleDateString('en-US', { weekday: 'short' });
          const monthDay = dateObj.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
          const year = dateObj.getFullYear();

          return (
            <div key={date} className="grid grid-cols-1 md:grid-cols-[140px_1fr] gap-4 items-start">
              {/* Left Asymmetrical Sticky Column */}
              <div className="md:sticky md:top-20 space-y-1">
                <div className="flex items-baseline md:flex-col md:items-start gap-2">
                  <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">{weekday}</span>
                  <span className="text-sm font-semibold text-zinc-200">{monthDay}</span>
                </div>
                <span className="hidden md:block text-[10px] text-zinc-600 font-bold">{year}</span>
              </div>

              {/* Right Notes Cascade Column */}
              <div className="space-y-3">
                {grouped[date].map((note) => (
                  <div
                    key={note.id}
                    className="group bg-zinc-900/20 hover:bg-zinc-900/40 border-l border-t border-r border-b border-zinc-850 hover:border-zinc-800 rounded-md p-4 flex flex-col justify-between gap-3 transition-colors relative"
                  >
                    <p className="text-xs text-zinc-300 leading-relaxed whitespace-pre-wrap">
                      {note.content}
                    </p>
                    
                    <div className="flex items-center justify-between border-t border-zinc-900 pt-2 text-[9px] font-bold uppercase tracking-wider text-zinc-550">
                      <span>
                        {new Date(note.created_at).toLocaleTimeString('en-US', {
                          hour: 'numeric',
                          minute: '2-digit',
                          hour12: true
                        })}
                      </span>
                      
                      <button
                        onClick={() => deleteNote(note.id)}
                        className="p-1 hover:bg-zinc-800 text-zinc-600 hover:text-red-400 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Delete note"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {dates.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center border border-dashed border-zinc-850 rounded">
            <p className="text-xs text-zinc-500 uppercase tracking-wider font-bold">No saved notes</p>
          </div>
        )}
      </div>
    </div>
  );
}



