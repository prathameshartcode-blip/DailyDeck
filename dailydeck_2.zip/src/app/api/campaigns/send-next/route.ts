import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import nodemailer from 'nodemailer';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get('authorization');
    const body = await req.json();
    const { campaign_id, smtp_user, smtp_pass } = body;

    if (!campaign_id) {
      return NextResponse.json({ error: 'Missing campaign_id' }, { status: 400 });
    }

    if (!smtp_user || !smtp_pass) {
      return NextResponse.json({ error: 'Missing SMTP credentials' }, { status: 400 });
    }

    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: { headers: { Authorization: authHeader || '' } }
    });

    // 1. Fetch the campaign details
    const { data: campaign, error: campaignError } = await supabase
      .from('email_campaigns')
      .select('*')
      .eq('id', campaign_id)
      .single();

    if (campaignError || !campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }

    if (campaign.status !== 'in_progress') {
      return NextResponse.json({ error: 'Campaign is not in progress' }, { status: 400 });
    }

    // 2. Fetch the next single pending recipient
    const { data: nextRecipient, error: queueError } = await supabase
      .from('email_queue')
      .select('*')
      .eq('campaign_id', campaign_id)
      .eq('status', 'pending')
      .order('created_at', { ascending: true })
      .limit(1)
      .single();

    // If no pending recipient found, the campaign is complete!
    if (queueError && queueError.code === 'PGRST116') { // PGRST116 is "No rows found"
      await supabase
        .from('email_campaigns')
        .update({ status: 'completed' })
        .eq('id', campaign_id);
      
      return NextResponse.json({ status: 'completed', message: 'All emails sent' });
    }
    
    if (queueError) throw queueError;

    // 3. Instantiate Transporter dynamically
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      auth: {
        user: smtp_user,
        pass: smtp_pass,
      },
    });

    // 4. Send the email via Nodemailer
    try {
      await transporter.sendMail({
        from: smtp_user,
        to: nextRecipient.recipient_email,
        subject: campaign.subject,
        text: campaign.body, // In a real app you can send HTML here as well
      });

      // Update to sent
      await supabase
        .from('email_queue')
        .update({ status: 'sent', sent_at: new Date().toISOString() })
        .eq('id', nextRecipient.id);

    } catch (emailError: any) {
      // Update to failed but do NOT crash the route, so relay can continue
      await supabase
        .from('email_queue')
        .update({ status: 'failed', error_message: emailError.message })
        .eq('id', nextRecipient.id);
    }

    // 5. Return success so the client knows to trigger the next one
    return NextResponse.json({ 
      status: 'sent_one', 
      processed_email: nextRecipient.recipient_email 
    });

  } catch (error: any) {
    console.error('Send next error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
